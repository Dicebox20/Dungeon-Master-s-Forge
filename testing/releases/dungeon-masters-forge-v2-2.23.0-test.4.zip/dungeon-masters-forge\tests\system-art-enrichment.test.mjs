import assert from "node:assert/strict";
import {
  applySpellActivityArt,
  applySystemEquipmentArt,
  spellActivityMatches,
  supportsSystemEquipmentArt
} from "../scripts/system-art-enrichment.js";

assert.equal(supportsSystemEquipmentArt({ kind: "weaponExtraDamage" }), true);
assert.equal(supportsSystemEquipmentArt({ kind: "artifactWeaponHybrid" }), false);

const blade = applySystemEquipmentArt({
  kind: "weaponExtraDamage",
  name: "Flame-Thunder Greatsword",
  img: "icons/svg/item-bag.svg"
}, "systems/dnd5e/icons/svg/items/greatsword.webp");
assert.equal(blade.img, "systems/dnd5e/icons/svg/items/greatsword.webp");

const artifact = applySystemEquipmentArt({
  kind: "artifactWeaponHybrid",
  name: "Worldrender"
}, "systems/dnd5e/icons/svg/items/greataxe.webp");
assert.equal(artifact.img, undefined);

assert.equal(spellActivityMatches("Cast Fireball", "Fireball"), true);
assert.equal(spellActivityMatches("Fireball", "Fireball"), true);
assert.equal(spellActivityMatches("Flame Strike", "Fireball"), false);

const suite = applySpellActivityArt({
  kind: "equipmentPowerSuite",
  utilityActivities: [
    { activityName: "Cast Fireball" },
    { activityName: "Cast Lightning Bolt" }
  ]
}, "Fireball", "systems/dnd5e/icons/svg/spells/fireball.webp");

assert.equal(suite.utilityActivities[0].activityImg, "systems/dnd5e/icons/svg/spells/fireball.webp");
assert.equal(suite.utilityActivities[1].activityImg, undefined);

export const testedSystemArtCases = 7;
